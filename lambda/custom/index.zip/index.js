const Alexa = require('alexa-sdk');

const APP_ID = 'amzn1.ask.skill.91c64c70-77c9-4706-a9c8-fd08a8317b0c';

const languageStrings = {
    'en-US': {
        'translation': {
            'GAME_NAME'  : "Just Name It!",
            'GREETING':"Think Fast and Name it out! Welcome to Just Name It. Test your brain or have fun with your friends. You can say Rule to listen the rules, or say Start to start game. say Rule or Start?",
            'START_OVER':"Would you like to start another game?",
            'REPEAT_TOPIC': "To repeat the topic, say, repeat.",
            'HELP_MESSAGE': "I will give you a random category of words! You have 10 seconds to name the right word. If your answer does not include or repeat your answer before. The game over. Are you ready to begin?",
            'SKIP_MESSAGE': "You can skip to next category by saying \"Skip.\"",
            'NAME_IT_RIGHT': "Correct! Next",
            'READY': "Ready, Go!",
            'COUNTDOWN': "5 4 3 2 1",
            'TIME_UP': "Time's up!",
            'REPEATED_NAME': "You already named it!",
            'GAME_OVER_MESSAGE': "You lose!",
            'BOTTOM_UP':"If you hold beer in your hand, Bottom up!",
            "START_UNHANDLED": "Say start to start a new game.",
            "GAME_UNHANDLED": "I don\'t think that is the right name",
            "CANCEL_MESSAGE": "I feel you. Let\'s play again soon.",
        },
    },
};

const ALL_GAMEMODES = [
    { category:"Name European Cars", answerSet:[
      'Fiat','Alfa Romeo','Ferrari','Lambogini',
      'Aston Martin','McLarlen','Pagani','BMW','Mercedez-Benz',
      'Porche'
    ], gamecode:'ecar' },
    { category:"Name Country with 3 syllables", answerSet:[
      'Mexico','Germany','Portugal','Honduras',
      'Paraguay','Colombia','Liechtenstein',
      'Malaysia','Pakistan','Canada',
      'Lebanon','Netherlanda','Italy','Romania','Israel',
      'Croatia','Monaco','Moldova','Kosovo','Luxembourg',
      'Hungary','Andorra','Uruguay','Guyana','Ecuador',
      'Bangladesh','East Timor','Kyrgyzstan','Kazakhstan',
      'Philippines','Singapore','Sri Lanka','Angola','Botswana',
      'Burundi','Cameroon','Cape Verde','Malawi','Morocco','Mozambique',
      'Rwanda','Senegal','South Sudan','Uganda','New Zealand',
      'Bahamas','Jamaica','Panama','Bulgaria'
    ], gamecode:'coun' },
    { category:"Name European Capitals with 2 syllables", answerSet:[
      {nation:'Austria',cap:'Vienna'},{nation:'Belgium',cap:'Brussels'},
      {nation:'Bulgaria',cap:'Sofia'},{nation:'Croatia',cap:'Zagrep'},
      {nation:'Estonia',cap:'Tallinn'},{nation:'France',cap:'Paris'},
      {nation:'Greece',cap:'Athens'},{nation:'Ireland',cap:'Dublin'},
      {nation:'Latvia',cap:'Riga'},{nation:'Liechtenstein',cap:'Vaduz'},
      {nation:'Norway',cap:'Oslo'},{nation:'Poland',cap:'Warsaw'},
      {nation:'Portugal',cap:'Lisbon'},{nation:'Russia',cap:'Moscow'},
      {nation:'Serbia',cap:'Belgrade'},{nation:'Spain',cap:'Madrid'},
      {nation:'Sweden',cap:'Stockholm'},{nation:'England',cap:'London'},
      {nation:'Lithuania',cap:'Vilnius'},{nation:'Wales',cap:'Cardiff'},
      {nation:'Northern Ireland',cap:'Belfast'},
    ], gamecode:'ecap' }
];

const states = {
    START:     "_START",
    GAMEMODE:      "_GAMEMODE",
};

//shuffle function for ALL_GAMEMODES object
const shuffleGames = function(allgames) {
  let index = allgames.length;
  let shuffledGames = allgames;
  for (let i = 0; i < allgames.length ; i++) {
        const rand = Math.floor(Math.random() * index);
        index -= 1;
        const temp = shuffledGames[index];
        shuffledGames[index] = shuffledGames[rand];
        shuffledGames[rand] = temp;
  }
  return shuffledGames;
};
//new session handler
const newSessionHandlers = {
  "LaunchRequest": function() {
    this.handler.state = states.START;
    this.emitWithState('StartGame');
  },
  "AMAZON.HelpIntent": function () {
    this.response.speak(this.t("HELP_MESSAGE"))
                .listen(this.t("HELP_MESSAGE"));
    this.emit(':responseReady');
  },
  "Unhandled": function () {
    const speechOutput = this.t("START_UNHANDLED");
    this.response.speak(speechOutput).listen(speechOutput);
    this.emit(":responseReady");
  },
};

//start state handler need to set up attributes
const startStateHandlers = Alexa.CreateStateHandler(states.START, {
  "StartGame": function() {
    if ( Object.keys(this.attributes).length === 0 ) {
      this.attributes['gameSets'] = ALL_GAMEMODES;
      this.attributes['currentCategoryTopic'] = ALL_GAMEMODES[1]["category"];
      this.attributes['currentCategoryIndex'] = 1;
      this.attributes['alreadyNamedWord'] = [];
      this.attributes['remainingAnswer'] = ALL_GAMEMODES[1]["answerSet"];
      this.attributes['speechOutput'] = "";

      console.log(this.attributes['currentCategoryTopic']);
    }

    this.handler.state = states.GAMEMODE;
    this.response.speak(this.t('GREETING'));
    this.emit(':responseReady');
  },
  //"GameIntent": function() {
    //this.handler.state = states.GAMEMODE;
    //read topic => render topic => countdown to start logic
    //this.attributes['gameSets'][0]["category"] + this.t("READY");
    //let speechOutput = "Let\'s start"
    //this.response.speak(speechOutput);
    //this.emit(':responseReady');
  //},
  "AMAZON.HelpIntent": function () {
    this.response.speak(this.t("HELP_MESSAGE"))
                .listen(this.t("HELP_MESSAGE"));
    this.emit(':responseReady');
  },
  "AMAZON.CancelIntent": function() {
    this.response.speak("Goodbye!");
    this.emit(':responseReady');
  },
  "AMAZON.StopIntent": function() {
    this.response.speak("Goodbye!");
    this.emit(':responseReady');
  }
});

//handle game state
const gameStateHandlers = Alexa.CreateStateHandler(states.GAMEMODE, {
  'AMAZON.YesIntent': function () {
    this.handler.state = states.START;
    this.emitWithState("StartGame");
  },
  "AMAZON.StartOverIntent": function () {
    this.handler.state = states.START;
    this.emitWithState("StartGame");
  },
  'NameItIntent' : function() {
    const guessName = this.event.request.intent.slot.Answer.value;
    const correctNameSet = this.attributes['remainingAnswer'];
    const alreadyNamed = [];

    console.log('user name : '+ guessName);

    if ( correctNameSet.includes(guessName) && !alreadyNamed.includes(guessName)) {
      alreadyNamed.push(guessName);
      this.response.speak(this.t("NAME_IT_RIGHT"))
                  .cardRenderer(this.attributes['currentCategoryTopic'], guessName)
                  .listen(this.t("COUNTDOWN"));
      this.emit(':responseReady');
    } else if ( alreadyNamed.includes(guessName)) {
      this.response.speak(this.t("REPEATED_NAME"))
                  .cardRenderer(this.t("GAME_OVER_MESSAGE"))
                  .listen(this.t("START_OVER"));
      this.emit(":responseReady");
    } else {
      this.response.speak(this.t("GAME_OVER_MESSAGE"))
                  .listen(this.t("START_OVER"));
      this.emit(":responseReady");
    }
    //create function handleAnswer and then .call(this) in this intent
  },
  "AMAZON.RepeatIntent": function () {
      this.response.speak(this.attributes["currentCategoryTopic"]);
      this.emit(":responseReady");
  },
  "AMAZON.StopIntent": function () {
      this.response.speak("Stop game").listen("Would you like to start over?");
      this.emit(":responseReady");
  },
  "AMAZON.CancelIntent": function () {
      this.response.speak(this.t("CANCEL_MESSAGE"));
      this.emit(":responseReady");
  },
  "SessionEndedRequest": function () {
      console.log(`Session ended in game state: ${this.event.request.reason}`);
  },
});

exports.handler = function(event, context) {
    const alexa = Alexa.handler(event, context);
    alexa.resources = languageStrings;
    alexa.appId = APP_ID; // APP_ID is your skill id which can be found in the Amazon developer console where you create the skill.
    alexa.registerHandlers(newSessionHandlers, startStateHandlers, gameStateHandlers);
    alexa.execute();
};
